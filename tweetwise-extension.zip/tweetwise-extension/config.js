const CONFIG = {
    API_URL: 'https://tweetwise-api.mlnb.org/api/v1'
}